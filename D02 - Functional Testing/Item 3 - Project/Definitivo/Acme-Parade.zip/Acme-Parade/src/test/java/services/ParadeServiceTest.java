
package services;

import java.text.SimpleDateFormat;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import utilities.AbstractTest;
import domain.Parade;
import domain.Segment;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ParadeServiceTest extends AbstractTest {

	@Autowired
	private ParadeService	paradeService;

	@Autowired
	private SegmentService	segmentService;



	/* TEST 1
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to Make a copy of one of their parades. The parade must be in final mood.
	 * - Analysis of sentence coverage of ParadeService: 39.9%
	 * 	Total instructions: 416; Covered Instructions: 116
	 * - Analysis of data coverage: 53.12%
	 * 		Attribute: FinalMode| Bad value: false | Normal value: Yes | Coverage: 100% |
	 * 		Attribute: ticker|Bad value: - | Normal value: Yes | Coverage: 50% |
	 * 		Attribute: title| Bad value: - | Normal value: Yes | Coverage: 50% |
	 * 		Attribute: description | Bad value: - | Normal value: Yes | Coverage: 50% |
	 * 		Attribute: momentOrganised | Bad value: - | Normal value: Yes | Coverage: 25% |
	 * 		Attribute: status | Bad value: - | Normal value: Yes | Coverage: 50% |
	 * 		Attribute: whyRejected | Bad value: - | Normal value: Yes | Coverage: 50% |
	 * 		Attribute: openPath | Bad value: - | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void test1() {
		final Object testingData[][] = {
			{
				//Test positivo
				"brotherhood1", "parade1", true, null
			}, {
				//Test negativo
				"brotherhood1", "parade1", false, IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (Boolean) testingData[i][2], (Class<?>) testingData[i][3]);
	}

	protected void template(final String username, final int paradeId, final boolean finalMode, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);

			Parade p;
			p = this.paradeService.findOne(paradeId);
			p.setFinalMode(finalMode);
			this.paradeService.copyParade(paradeId);

			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * TEST 2 and TEST 3
	 *
	 * Test 2: Requirement tested: An actor who is authenticated as a brotherhood must be able to Manage the paths of their parades, which includes creating
	 * 
	 * Test 3: Requirement tested: An actor who is authenticated as a brotherhood must be able to Manage the paths of their parades, which includes updating
	 * 
	 * - Analysis of sentence coverage of SegmentService: 36.7%
	 * Total instructions: 103; Covered Instructions: 281
	
	 * - Analysis of data coverage: 25%
	 * Attribute: arriveTime | Bad value: - | Normal value: Yes | Coverage: 25% |
	 * Attribute: number | Bad value: - | Normal value: Yes | Coverage: 25% |
	 * Attribute: Latitude | Bad value: - | Normal value: Yes | Coverage: 25% |
	 * Attribute: Longitude | Bad value: - | Normal value: Yes | Coverage: 25% |
	 */
	@Test
	public void test2() {
		final Object testingData[][] = {
			{
				//Test positivo
				"brotherhood1", "parade1", 1, 20.0, 45.0, "22:50", null
			}, {
				//Test negativo
				"member1", "parade1", 1, 20.0, 45.0, "22:50", IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template2((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (Integer) testingData[i][2], (Double) testingData[i][3], (Double) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6]);
	}

	protected void template2(final String username, final Integer paradeId, final Integer number, final Double latitude, final Double longitude, final String arriveTime, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		final SimpleDateFormat format = new SimpleDateFormat("hh:mm");
		try {
			this.authenticate(username);

			Parade p;
			p = this.paradeService.findOne(paradeId);
			Segment s;
			s = this.segmentService.create(p);
			s.setNumber(number);
			s.getSegment().setLatitude(latitude);
			s.getSegment().setLongitude(longitude);
			s.setArriveTime(format.parse(arriveTime));
			this.segmentService.save(s);

			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void test3() {
		final Object testingData[][] = {
			{
				//Test positivo
				"brotherhood1", "segment1", 1, 20.0, 45.0, "22:50", null
			}, {
				//Test negativo
				"member1", "segment1", 1, 20.0, 45.0, "22:50", IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template3((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (int) testingData[i][2], (Double) testingData[i][3], (Double) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6]);
	}

	protected void template3(final String username, final int segmentId, final int number, final Double latitude, final Double longitude, final String arriveTime, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		final SimpleDateFormat format = new SimpleDateFormat("hh:mm");
		try {
			this.authenticate(username);

			Segment s;
			s = this.segmentService.findOne(segmentId);
			s.setNumber(number);
			s.getSegment().setLatitude(latitude);
			s.getSegment().setLongitude(longitude);

			s.setArriveTime(format.parse(arriveTime));
			this.segmentService.save(s);
			this.unauthenticate();

		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

}
