
package services;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import security.Authority;
import utilities.AbstractTest;
import utilities.Utiles;
import domain.Chapter;
import domain.Parade;
import domain.Proclaim;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class ChapterServiceTest extends AbstractTest {

	@Autowired
	private ActorService	actorService;

	@Autowired
	private AreaService		areaService;

	@Autowired
	private ParadeService	paradeService;

	@Autowired
	private ProclaimService	proclaimeService;


	/*
	 * Requirement tested: An actor who is not authenticated must be able to register to the system as a chapter.
	 * - Analysis of sentence coverage of ActorService: 17,1%
	 * Total instructions: 1322; Covered Instructions: 226
	 * - Analysis of data coverage: 71.43%
	 * Attribute: Name | Bad value: null | Normal value: Yes | Coverage: 100% |
	 * Attribute: Surname | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: MiddleName | Bad value: --- | Normal value: Yes | Coverage: 100% | Reason: It's optional
	 * Attribute: Email | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: Phone | Bad value: --- | Normal value: Yes | Coverage: 50% | Reason: It's optional
	 * Attribute: Photo | Bad value: --- | Normal value: Yes | Coverage: 100% | Reason: It's optional
	 * Attribute: Title | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void testRegisterChapter() {
		final Object testingData[][] = {
			{
				//Positive test
				"Bel�n", "Garrido", "BGL", "belen@example.com", "666444333", "http://www.hola.com", "DP", null
			}, {
				// Negative test: The business rule that has been violated: Name cannot be blank
				"", "Garrido", "BGL", "belen@example.com", "666444333", "http://www.hola.com", "DP", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.registerChapter(i, (String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (String) testingData[i][6],
				(Class<?>) testingData[i][7]);
	}
	protected void registerChapter(final int i, final String name, final String surname, final String middleName, final String email, final String phone, final String photo, final String title, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {

			Chapter c;
			c = (Chapter) this.actorService.createActor(Authority.CHAPTER);
			c.setName(name);
			c.setSurname(surname);
			c.setMiddleName(middleName);
			c.setEmail(email);
			c.setPhone(phone);
			c.setPhoto(photo);
			c.setTitle(title);
			c.getAccount().setUsername("chapterJunit4" + i);
			c.getAccount().setPassword(Utiles.hashPassword("chapterJunit4"));

			this.actorService.save(null, null, null, c, null);
			this.actorService.flushRepository();
			this.actorService.flushChapter();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}

		super.checkExceptions(expected, caught);
	}

	/*
	 * Requirement tested: An actor who is authenticated as a chapter must be able to self-assign an area to co-ordinate.
	 * Analysis of sentence coverage of AreaService: 36.9%
	 * Total instructions: 149; Covered Instructions: 55
	 * Analysis of data coverage: 50%
	 * Attribute: Id | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void testAssignArea() {
		final Object testingData[][] = {
			{
				//Positive test
				"chapter1", "area1", null
			}, {
				//Negative test: The business rule that has been violated: Once an area is self-assigned, 
				//	it cannot be changed (or assigned to another chapter)
				"chapter2", "area1", IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.assignArea((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (Class<?>) testingData[i][2]);
	}

	protected void assignArea(final String username, final int areaId, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			super.authenticate(username);
			this.areaService.setArea(areaId);
			super.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Requirement tested: An actor who is authenticated as a chapter must be able to making decisions on the parades that have status submitted.
	 * Analysis of sentence coverage of ParadeService: 48.8%
	 * Total instructions: 416; Covered Instructions: 203
	 * Analysis of data coverage: 66.66%
	 * Attribute: Status | Bad value: --- | Normal value: Yes | Coverage: 33.33% | There are three types of status: ACCEPTED, REJECTED or SUBMITTED
	 * Attribute: ReasonWhyRejected | Bad value: null | Normal value: Yes | Coverage: 100% |
	 */
	@Test
	public void testChangeParadeStatus() {
		final Object testingData[][] = {
			{
				//Positive test
				"chapter1", "parade1", "REJECTED", "No procede", null
			}, {
				//Negative test: The business rule that has been violated: When a parade is rejected by a chapter, the chapter must jot down the reason why.
				"chapter1", "parade1", "REJECTED", null, IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.changeParadeStatus((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (String) testingData[i][2], (String) testingData[i][3], (Class<?>) testingData[i][4]);
	}

	protected void changeParadeStatus(final String username, final int paradeId, final String status, final String reason, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			super.authenticate(username);
			Parade p;
			p = this.paradeService.findOne(paradeId);
			p.setStatus(status);
			p.setWhyRejected(reason);
			this.paradeService.save(p);
			super.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Requirement tested: An actor who is authenticated as a chapter must be able to publish a proclaim
	 * Analysis of sentence coverage for the next two test of ProclaimService: 49.2%
	 * Total instructions: 193; Covered Instructions: 95
	 * Analysis of data coverage: 66.66%
	 * Attribute: Chapter | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: FinalMode | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: Text | Bad value: null | Normal value: Yes | Coverage: 100% |
	 */
	@Test
	public void testCreateProclaim() {

		final Object testingData[][] = {
			{
				//Positive test
				"chapter1", "chapter1", false, "No procede", "2019-03-25", null
			}, {
				//Negative test: The business rule that has been violated: Text cannot be blank
				"chapter1", "chapter1", false, "", "2019-03-25", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.createProclaim((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (boolean) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (Class<?>) testingData[i][5]);
	}
	protected void createProclaim(final String username, final int chapterId, final boolean finalMode, final String text, final String moment, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			super.authenticate(username);
			Proclaim p;
			p = this.proclaimeService.createProclaim();
			Chapter c;
			c = this.actorService.findOneChapter(chapterId);
			p.setChapter(c);
			p.setFinalMode(finalMode);
			p.setText(text);
			try {
				p.setMoment(format.parse(moment));
			} catch (final ParseException e) {
				e.printStackTrace();
			}
			this.proclaimeService.save(p);
			this.proclaimeService.flush();
			super.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Requirement tested: An actor who is authenticated as a chapter must be able to update a proclaim
	 * Analysis of data coverage: 50%
	 * Attribute: Chapter | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: FinalMode | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: Text | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void testUpdateProclaim() {

		final Object testingData[][] = {
			{
				//Positive test
				"chapter1", "proclaim1", true, "No procede", null
			}, {
				//Negative test: The business rule that has been violated: Note that once a proclaim is published, there's no way to update or delete it.
				"chapter1", "proclaim1", false, "No procede", IllegalArgumentException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.updateProclaim((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (boolean) testingData[i][2], (String) testingData[i][3], (Class<?>) testingData[i][4]);
	}
	protected void updateProclaim(final String username, final int proclaimId, final boolean finalMode, final String text, final Class<?> expected) {
		Class<?> caught;
		caught = null;
		try {
			super.authenticate(username);
			Proclaim p;
			p = this.proclaimeService.findOne(proclaimId);
			p.setFinalMode(finalMode);
			p.setText(text);
			this.proclaimeService.save(p);
			super.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

}
