
package services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

import javax.transaction.Transactional;
import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import utilities.AbstractTest;
import domain.InceptionRecord;
import domain.LegalRecord;
import domain.LinkRecord;
import domain.MiscellaneousRecord;
import domain.PeriodRecord;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/junit.xml"
})
@Transactional
public class HistoryTest extends AbstractTest {

	@Autowired
	private ActorService				actorService;

	@Autowired
	private InceptionRecordService		inceptionService;

	@Autowired
	private LegalRecordService			legalService;

	@Autowired
	private LinkRecordService			linkService;

	@Autowired
	private MiscellaneousRecordService	miscellaneousService;

	@Autowired
	private PeriodRecordService			periodService;

	@Autowired
	private HistoryService				historyService;


	/*
	 * all the following tests are related to history so we have 100%
	 * coverage in historyServices as we go through all the code lines of this service.
	 */
	/*
	 * Requirement tested: Display the history of every brotherhood that he or she can display.
	 * Analysis of sentence coverage of each recordService's findOne: 100%
	 */
	@Test
	public void inceptionRecordDisplay() {
		final Object testingData[][] = {
			{
				//Positive test: Display any record to a unauthenticated actor
				null, "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}, {
				//Positive test: Display any record to a member
				"member1", "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}, {
				//Positive test: Display any record to a chapter
				"chapter1", "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}, {
				//Positive test: Display any record to a brotherhood
				"brotherhood1", "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}, {
				//Positive test: Display any record to a sponsor
				"sponsor1", "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}, {
				//Positive test: Display any record to a admin
				"admin1", "inceptionRecord1", "history1", "periodRecord1", "miscellaneousRecord1", "legalRecord1", "linkRecord1", null
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), super.getEntityId((String) testingData[i][2]), super.getEntityId((String) testingData[i][3]), super.getEntityId((String) testingData[i][4]),
				super.getEntityId((String) testingData[i][5]), super.getEntityId((String) testingData[i][6]), (Class<?>) testingData[i][7]);
	}
	protected void template(final String username, final int idInception, final int idHistory, final int idPeriod, final int idMisc, final int idLegal, final int idLink, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			this.inceptionService.findOne(idInception);
			this.historyService.findOne(idHistory);
			this.legalService.findOne(idLegal);
			this.linkService.findOne(idLink);
			this.miscellaneousService.findOne(idMisc);
			this.periodService.findOne(idPeriod);
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Next two test are about InceptionRecordService
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to:
	 * Manage their history, which includes listing, displaying, creating, updating, and deleting its records.
	 * Total instructions: 124
	 * Covered instructions: 82
	 * Analysis of sentence coverage of InceptionRecordService: 66,1%
	 * Analysis of data coverage: 100%
	 * Attribute: title | Bad value: null, script | Normal value: Yes | Coverage: 100% |
	 * Attribute: description | Bad value: null, script | Normal value: Yes | Coverage: 100% |
	 */
	@Test
	public void inceptionRecordCreateySave() {
		final Object testingData[][] = {
			{
				//Positive test: Create a normal inceptionRecord 
				"brotherhood2", "description", "title", null
			}, {
				//Positive test: Create a normal inceptionRecord with <h1> 
				"brotherhood2", "<h1>description</h1>", "<h1>title</h1>", null
			}, {
				//Negative test: The business rule that has been violated: Title cannot be blank
				"brotherhood2", "description", null, ConstraintViolationException.class
			}, {
				//Negative test: The business rule that has been violated: Description cannot be blank
				"brotherhood2", null, "title", ConstraintViolationException.class
			}, {
				//Negative test: The business rule that has been violated: Member cannot create a inception record
				"member1", "description", "title", IllegalArgumentException.class
			}, {
				//Negative test: The business rule that has been violated: Unauthenticated actor cannot create a inception record
				null, "description", "title", IllegalArgumentException.class
			}, {
				//Negative test: The business rule that has been violated: Description cannot be a script
				"brotherhood2", "<script>alert('hola');</script>", "title", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3]);
	}
	protected void template(final String username, final String description, final String title, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			InceptionRecord i;
			i = this.inceptionService.createInceptionRecord();
			i.setDescription(description);
			i.setTitle(title);
			this.inceptionService.save(i);
			this.inceptionService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void inceptionRecordUpdate() {
		final Object testingData[][] = {
			{
				//Positive test: Update all data  of a normal inceptionRecord 
				"brotherhood1", "inceptionRecord1", "description2", "title2", null
			}, {
				//Positive test: Update title of a normal inceptionRecord
				"brotherhood1", "inceptionRecord1", "", "title2", null
			}, {
				//Positive test: Update description of a normal inceptionRecord
				"brotherhood1", "inceptionRecord1", "description2", "", null
			}, {
				//Negative test: The business rule that has been violated: Title cannot be blank
				"brotherhood1", "inceptionRecord1", "description", null, ConstraintViolationException.class
			}, {
				//Negative test: The business rule that has been violated: Description cannot be blank
				"brotherhood1", "inceptionRecord1", null, "title", ConstraintViolationException.class
			}, {
				//Negative test: The business rule that has been violated: Member cannot update a inception record
				"member1", "inceptionRecord1", "description", "title", IllegalArgumentException.class
			}, {
				//Negative test: The business rule that has been violated: Unauthenticated actor cannot update a inception record
				null, "inceptionRecord1", "descrption", "title", IllegalArgumentException.class
			}, {
				//Negative test: The business rule that has been violated: Description cannot be a script
				"brotherhood1", "inceptionRecord1", "<script>alert('hola');</script>", "title", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template2((String) testingData[i][0], super.getEntityId((String) testingData[i][1]), (String) testingData[i][2], (String) testingData[i][3], (Class<?>) testingData[i][4]);
	}
	protected void template2(final String username, final int idInception, final String description, final String title, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			InceptionRecord i;
			i = this.inceptionService.findOne(idInception);
			if (description != "")
				i.setDescription(description);
			if (title != "")
				i.setTitle(title);
			this.inceptionService.save(i);
			this.inceptionService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Next two test are about LegalRecordService
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to:
	 * Manage their history, which includes listing, displaying, creating, updating, and deleting its records.
	 * Total instructions: 194
	 * Covered instructions: 98
	 * Analysis of sentence coverage of LegalRecordService: 50,5%
	 * Analysis of data coverage: 56,6%
	 * Attribute: title | Bad value: null | Normal value: Yes | Coverage: 100% |
	 * Attribute: description | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: legalName | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: vat | Bad value: max | Normal value: Yes | Coverage: 33% |
	 * Attribute: laws | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void legalRecordCreateySave() {
		final Object testingData[][] = {
			{
				//Positive test: Create a normal legal record
				"brotherhood1", "description", "title", "legalname", 3, "laws", null
			}, {
				//Negative test: The business rule that has been violated: Description cannot be blank
				"brotherhood1", null, "title", "legalname", 3, "laws", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template3((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (int) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6]);
	}
	protected void template3(final String username, final String description, final String title, final String legalName, final int vat, final String laws, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			LegalRecord l;
			l = this.legalService.createLegalRecord();
			l.setDescription(description);
			l.setTitle(title);
			l.setLegalName(legalName);
			l.setVat(vat);
			final Collection<String> col;
			col = new ArrayList<String>();
			col.add(laws);
			l.setLaws(col);
			this.legalService.save(l);
			this.legalService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void legalRecordUpdate() {
		final Object testingData[][] = {
			{
				//Positive test: Update a legal record
				"brotherhood1", "description2", "title2", "legalname", 3, "laws", null, "legalRecord1"
			}, {
				//Negative test: The business rule that has been violated: VAT is a percentage and must be between 0 and 100
				"brotherhood1", "description2", "title", "legalname", 101, "laws", ConstraintViolationException.class, "legalRecord1"
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template4((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (int) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6],
				super.getEntityId((String) testingData[i][7]));
	}
	protected void template4(final String username, final String description, final String title, final String legalName, final int vat, final String laws, final Class<?> expected, final int idLegal) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			LegalRecord l;
			l = this.legalService.findOne(idLegal);
			l.setDescription(description);
			l.setTitle(title);
			l.setLegalName(legalName);
			l.setVat(vat);
			final Collection<String> col;
			col = new ArrayList<String>();
			col.add(laws);
			l.setLaws(col);
			this.legalService.save(l);
			this.legalService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Next two test are about LinkRecordService
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to:
	 * Manage their history, which includes listing, displaying, creating, updating, and deleting its records.
	 * Total instructions: 187
	 * Covered instructions: 92
	 * Analysis of sentence coverage of LinkRecordService: 49,2%
	 * Analysis of data coverage: 83,3%
	 * Attribute: title | Bad value: null | Normal value: Yes | Coverage: 100% |
	 * Attribute: description | Bad value: null | Normal value: Yes | Coverage: 100% |
	 * Attribute: brotherhood | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void linkRecordCreateySave() {
		final Object testingData[][] = {
			{
				//Positive test: Create a link record
				"brotherhood1", "description", "tile", "brotherhood2", null
			}, {
				//Negative test: The business rule that has been violated: Title cannot be blank
				"brotherhood1", "description", null, "brotherhood2", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template5((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], super.getEntityId((String) testingData[i][3]), (Class<?>) testingData[i][4]);
	}
	protected void template5(final String username, final String description, final String title, final int brotherhood, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			LinkRecord li;
			li = this.linkService.createLinkRecord();
			li.setDescription(description);
			li.setTitle(title);
			li.setBrotherhood(this.actorService.findOneBrotherhood(brotherhood));
			this.linkService.save(li);
			this.linkService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void linkRecordUpdate() {
		final Object testingData[][] = {
			{
				//Positive test: Update a link record
				"brotherhood1", "description", "tile", "brotherhood2", null, "linkRecord1"
			}, {
				//Negative test: The business rule that has been violated: Description cannot be blank
				"brotherhood1", null, "title", "brotherhood2", ConstraintViolationException.class, "linkRecord1"
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template6((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], super.getEntityId((String) testingData[i][3]), (Class<?>) testingData[i][4], super.getEntityId((String) testingData[i][5]));
	}
	protected void template6(final String username, final String description, final String title, final int brotherhood, final Class<?> expected, final int idLink) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			LinkRecord li;
			li = this.linkService.findOne(idLink);
			li.setDescription(description);
			li.setTitle(title);
			li.setBrotherhood(this.actorService.findOneBrotherhood(brotherhood));
			this.linkService.save(li);
			this.linkService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Next two test are about MiscellaneousRecordService
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to:
	 * Manage their history, which includes listing, displaying, creating, updating, and deleting its records.
	 * Total instructions: 170
	 * Covered instructions: 87
	 * Analysis of sentence coverage of MiscellaneousRecordService: 51,2%
	 * Analysis of data coverage: 100%
	 * Attribute: title | Bad value: null | Normal value: Yes | Coverage: 100% |
	 * Attribute: description | Bad value: null | Normal value: Yes | Coverage: 100% |
	 */
	@Test
	public void MiscellaneousRecordCreateySave() {
		final Object testingData[][] = {
			{
				//Positive test: Create a miscellaneous record
				"brotherhood1", "description", "tile", null
			}, {
				//Negative test: The business rule that has been violated: Title cannot be blank
				"brotherhood1", "description", null, ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template7((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3]);
	}
	protected void template7(final String username, final String description, final String title, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			MiscellaneousRecord m;
			m = this.miscellaneousService.createMiscellaneousRecord();
			m.setDescription(description);
			m.setTitle(title);
			this.miscellaneousService.save(m);
			this.miscellaneousService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void MiscellaneousRecordUpdate() {
		final Object testingData[][] = {
			{
				//Positive test: Update a miscellaneous record
				"brotherhood1", "description", "tile", null, "miscellaneousRecord1"
			}, {
				//Negative test: The business rule that has been violated: Title cannot be blank
				"brotherhood1", null, "title", ConstraintViolationException.class, "miscellaneousRecord1"
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template8((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (Class<?>) testingData[i][3], super.getEntityId((String) testingData[i][4]));
	}
	protected void template8(final String username, final String description, final String title, final Class<?> expected, final int idMisc) {
		Class<?> caught;

		caught = null;
		try {
			this.authenticate(username);
			MiscellaneousRecord m;
			m = this.miscellaneousService.findOne(idMisc);
			m.setDescription(description);
			m.setTitle(title);
			this.miscellaneousService.save(m);
			this.miscellaneousService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	/*
	 * Next two test are about PeriodRecordService
	 * Requirement tested: An actor who is authenticated as a brotherhood must be able to:
	 * Manage their history, which includes listing, displaying, creating, updating, and deleting its records.
	 * Total instructions: 197
	 * Covered instructions: 102
	 * Analysis of sentence coverage of PeriodRecordService: 47,3%
	 * Analysis of data coverage: 43,2%
	 * Attribute: title | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: description | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 * Attribute: startDate | Bad value: max | Normal value: Yes | Coverage: 33% |
	 * Attribute: endDate | Bad value: --- | Normal value: Yes | Coverage: 20% |
	 * Attribute: photo | Bad value: --- | Normal value: Yes | Coverage: 50% |
	 */
	@Test
	public void periodRecordCreateySave() {
		final Object testingData[][] = {
			{
				//Positive test: Create a period record
				"brotherhood1", "description", "title", "2019-03-25", "2019-03-25", "photos", null
			}, {
				//Negative test: The business rule that has been violated: startDate cannot be a future date
				"brotherhood1", "description", "title", "2020-03-25", "2019-03-25", "photos", ConstraintViolationException.class
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template9((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6]);
	}
	protected void template9(final String username, final String description, final String title, final String startDate, final String endDate, final String photos, final Class<?> expected) {
		Class<?> caught;

		caught = null;
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.authenticate(username);
			PeriodRecord p;
			p = this.periodService.createPeriodRecord();
			p.setDescription(description);
			p.setTitle(title);
			p.setStartDate(format.parse(startDate));
			p.setEndDate(format.parse(endDate));
			final Collection<String> col;
			col = new ArrayList<String>();
			col.add(photos);
			p.setPhotos(col);
			this.periodService.save(p);
			this.periodService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}

	@Test
	public void periodRecordUpdate() {
		final Object testingData[][] = {
			{
				//Positive test: Update a period record
				"brotherhood1", "description", "title", "2019-03-25", "2019-03-25", "photos", null, "periodRecord1"
			}, {
				//Negative test: The business rule that has been violated: startDate cannot be a future date
				"brotherhood1", "description2", "title2", "2020-03-27", "2019-03-25", "photos", ConstraintViolationException.class, "periodRecord1"
			}
		};

		for (int i = 0; i < testingData.length; i++)
			this.template10((String) testingData[i][0], (String) testingData[i][1], (String) testingData[i][2], (String) testingData[i][3], (String) testingData[i][4], (String) testingData[i][5], (Class<?>) testingData[i][6],
				super.getEntityId((String) testingData[i][7]));
	}
	protected void template10(final String username, final String description, final String title, final String startDate, final String endDate, final String photos, final Class<?> expected, final int idPeriod) {
		Class<?> caught;

		caught = null;
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.authenticate(username);
			PeriodRecord p;
			p = this.periodService.findOne(idPeriod);
			p.setDescription(description);
			p.setTitle(title);
			p.setStartDate(format.parse(startDate));
			p.setEndDate(format.parse(endDate));
			final Collection<String> col;
			col = new ArrayList<String>();
			col.add(photos);
			p.setPhotos(col);
			this.periodService.save(p);
			this.periodService.flush();
			this.unauthenticate();
		} catch (final Throwable oops) {
			caught = oops.getClass();
		}
		super.checkExceptions(expected, caught);
	}
}
