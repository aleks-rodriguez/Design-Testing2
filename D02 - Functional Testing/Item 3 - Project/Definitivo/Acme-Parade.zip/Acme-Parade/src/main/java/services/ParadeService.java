
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;

import repositories.ParadeRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import utilities.Utiles;
import domain.Brotherhood;
import domain.Float;
import domain.Parade;
import domain.Request;
import domain.Sponsorship;

@Service
@Transactional
public class ParadeService {

	@Autowired
	private Validator			validator;

	@Autowired
	private ParadeRepository	paradeRepository;


	public Collection<Parade> findParadesByBrotherhoodIdFM(final int id) {
		return this.paradeRepository.findParadesByBrotherhoodIdFM(id);
	}

	public Collection<Parade> findParadesByBrotherhoodId(final int id) {
		final String lang = LocaleContextHolder.getLocale().getLanguage();
		Collection<Parade> res = null;
		if (lang == "en" || lang == null) {
			res = this.paradeRepository.findParadesByBrotherhoodId(id);
			if (res.isEmpty())
				res = this.paradeRepository.findParadesByBrotherhoodIdES(id);
		} else {
			res = this.paradeRepository.findParadesByBrotherhoodIdES(id);
			if (res.isEmpty())
				res = this.paradeRepository.findParadesByBrotherhoodId(id);
		}
		return res;
	}

	public Collection<Parade> findAll() {
		return this.paradeRepository.findAll();
	}

	public Parade findOne(final int idParade) {
		return this.paradeRepository.findOne(idParade);
	}
	public Collection<Parade> findParadesAFM() {
		return this.paradeRepository.findParadesAFM();
	}
	public Brotherhood findBrotherhoodByUser(final int userId) {
		return this.paradeRepository.findBrotherhoodByUserAccountId(userId);
	}

	public Brotherhood findBrotherhoodByParade(final int idParade) {
		return this.paradeRepository.findBrotherhoodByParadesId(idParade);
	}

	public Collection<Parade> findParadeByBrotherhoodId(final int idBrotherhood) {
		return this.paradeRepository.findParadesByBrotherhoodId(idBrotherhood);
	}
	public Collection<Sponsorship> findSponsorshipsByParadeId(final int idParade) {
		return this.paradeRepository.findSponsorshipByParadeId(idParade);
	}

	public Parade createParade() {
		UserAccount user;
		user = LoginService.getPrincipal();
		Assert.isTrue(Utiles.findAuthority(user.getAuthorities(), Authority.BROTHERHOOD));
		Brotherhood b;
		b = this.paradeRepository.findBrotherhoodByUserAccountId(LoginService.getPrincipal().getId());
		Assert.notNull(b.getArea(), "This brotherhood have no area selected");
		Parade p;
		p = new Parade();
		p.setTicker(Utiles.generateTicker(this.paradeRepository.findAllTickersSystem()));
		p.setTitle("");
		p.setDescription("");
		p.setMomentOrganised(new Date());
		p.setFinalMode(false);
		p.setRequests(new ArrayList<Request>());
		p.setFloats(new ArrayList<Float>());
		p.setStatus("SUBMITTED");
		p.setWhyRejected("");
		p.setOpenPath(true);
		return p;
	}
	public Parade save(final Parade parade) {
		UserAccount user;
		user = LoginService.getPrincipal();
		Parade saved = null;
		if (Utiles.findAuthority(user.getAuthorities(), Authority.BROTHERHOOD)) {
			Brotherhood b;
			b = this.paradeRepository.findBrotherhoodByUserAccountId(user.getId());
			Assert.notNull(b.getArea(), "This brotherhood has no area selected");
			saved = this.paradeRepository.save(parade);
			Collection<Parade> parades;
			parades = b.getParades();
			if (!parades.contains(saved)) {
				parades.add(saved);
				b.setParades(parades);
			}
			Assert.isTrue(b.getParades().contains(saved), "You don't have permission to delete this parade");
		} else if (Utiles.findAuthority(user.getAuthorities(), Authority.CHAPTER)) {
			if (parade.getStatus().equals("REJECTED"))
				Assert.notNull(parade.getWhyRejected(), "If status is rejected, Why reason must be filled");

			saved = this.paradeRepository.save(parade);

		}
		return saved;
	}

	public void delete(final int idParade) {
		UserAccount user;
		user = LoginService.getPrincipal();
		Assert.isTrue(Utiles.findAuthority(user.getAuthorities(), Authority.BROTHERHOOD));
		Parade p;
		p = this.paradeRepository.findOne(idParade);
		Brotherhood b;
		b = this.paradeRepository.findBrotherhoodByParadesId(idParade);
		Assert.isTrue(b.getParades().contains(p), "You don't have permission to delete this parade");
		Collection<Parade> paradesPerBrotherhood;
		paradesPerBrotherhood = b.getParades();
		if (paradesPerBrotherhood.contains(p)) {
			paradesPerBrotherhood.remove(p);
			b.setParades(paradesPerBrotherhood);
			this.paradeRepository.delete(p);
		}
	}

	public Parade reconstruct(final Parade parade, final BindingResult binding) {
		Parade result;
		if (parade.getId() == 0) {
			result = parade;
			result.setStatus(parade.getStatus());
			result.setOpenPath(true);
		} else {
			result = this.paradeRepository.findOne(parade.getId());
			result.setTicker(parade.getTicker());
			result.setTitle(parade.getTitle());
			result.setDescription(parade.getDescription());
			result.setFinalMode(parade.getFinalMode());
			result.setWhyRejected(parade.getWhyRejected());
			result.setStatus(parade.getStatus());

			if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.BROTHERHOOD)) {
				result.setFloats(parade.getFloats());
				result.setRequests(parade.getRequests());
			}

		}
		this.validator.validate(result, binding);

		if (binding.hasErrors())
			throw new ValidationException();

		return result;
	}

	public Parade copyParade(final int id) {

		Parade toCopy;
		toCopy = this.paradeRepository.findOne(id);

		Brotherhood b;
		b = this.findBrotherhoodByParade(toCopy.getId());

		Assert.isTrue(b.getAccount().getId() == LoginService.getPrincipal().getId());
		Assert.isTrue(toCopy.getFinalMode());

		Parade newParade;
		newParade = this.createParade();

		newParade.setTitle(toCopy.getTitle());
		newParade.setDescription(toCopy.getDescription());
		newParade.setFinalMode(false);
		newParade.setFloats(toCopy.getFloats());
		newParade.setMomentOrganised(toCopy.getMomentOrganised());
		newParade.setRequests(toCopy.getRequests());
		newParade.setTicker(Utiles.generateTicker(this.paradeRepository.findAllTickersSystem()));
		newParade.setStatus("SUBMITTED");
		newParade.setWhyRejected("");
		newParade.setOpenPath(true);

		Parade saved;
		saved = this.paradeRepository.save(newParade);

		Collection<Parade> parades;
		parades = b.getParades();
		parades.add(saved);
		b.setParades(parades);

		return saved;
	}
}
