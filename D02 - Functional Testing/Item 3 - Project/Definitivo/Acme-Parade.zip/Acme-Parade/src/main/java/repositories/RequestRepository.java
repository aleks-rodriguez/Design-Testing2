
package repositories;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Actor;
import domain.Member;
import domain.Parade;
import domain.Request;

@Repository
public interface RequestRepository extends JpaRepository<Request, Integer> {

	@Query("select a from Actor a where a.account.id = ?1")
	Actor findByUserAccount(int id);

	@Query("select a from Member a where a.account.id=?1")
	Member findMemberByUserAccount(int accountId);

	@Query("select a from Brotherhood a where a.account.id=?1")
	Member findBroByUserAccount(int accountId);

	@Query("select p.requests from Parade p where p.id = ?1")
	Collection<Request> getRequestByParadeId(int id);

	@Query("select p.requests from Enrolment e join e.brotherhood b join b.parades p where e.member.id = ?1 and p.id = ?2")
	Collection<Request> getRequestByParadeIdAndMemberId(int memberId, int procId);

	@Query("select p from Parade p join p.requests r where r.id=?1")
	Parade getParadeByRequestId(int reqId);

	@Query("select r.marchRow, r.marchColumn from Request r where r.status = 'APPROVED'")
	List<String[]> getOptimPosition();

	@Query("select m from Member m join m.requests r where r.id=?1")
	Member getMemberByRequestId(int idRequest);

}
