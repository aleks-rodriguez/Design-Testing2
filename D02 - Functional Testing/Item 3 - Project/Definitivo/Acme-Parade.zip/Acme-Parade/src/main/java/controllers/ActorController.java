
package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import services.ActorService;
import services.MessageService;
import utilities.Utiles;
import domain.Actor;
import domain.Administrator;
import domain.Brotherhood;
import domain.Chapter;
import domain.Member;
import domain.Sponsor;
import forms.ActorForm;

@Controller
@RequestMapping(value = {
	"/actor", "/brotherhood", "/member", "/administrator", "/chapter", "/sponsor"
})
public class ActorController extends AbstractController {

	@Autowired
	private ActorService	serviceActor;

	@Autowired
	private MessageService	messageService;


	@RequestMapping(value = "/listBrotherhood", method = RequestMethod.GET)
	public ModelAndView listBrotherhood() {
		ModelAndView result;
		result = this.custom(new ModelAndView("brotherhood/list"));
		result.addObject("brotherhoods", this.serviceActor.findAllBrotherhood());
		result.addObject("requestURI", "brotherhood/listBrotherhood.do");
		return result;
	}
	@RequestMapping(value = "/listChapter", method = RequestMethod.GET)
	public ModelAndView listChapter() {
		ModelAndView result;
		result = this.custom(new ModelAndView("chapter/list"));
		result.addObject("chapters", this.serviceActor.findAllChapters());
		result.addObject("requestURI", "chapter/listChapter.do");
		return result;
	}
	@RequestMapping(value = "/createAdmin", method = RequestMethod.GET)
	public ModelAndView createAdmin() {
		ModelAndView model;
		model = this.createEditModelAndView(this.serviceActor.map(this.serviceActor.createActor(Authority.ADMIN), Authority.ADMIN));
		model.addObject("authority", Authority.ADMIN);
		return model;
	}
	@RequestMapping(value = "/createMember", method = RequestMethod.GET)
	public ModelAndView createMember() {
		ModelAndView model;
		model = this.createEditModelAndView(this.serviceActor.map(this.serviceActor.createActor(Authority.MEMBER), Authority.MEMBER));
		model.addObject("authority", Authority.MEMBER);
		return model;
	}
	@RequestMapping(value = "/createBrotherhood", method = RequestMethod.GET)
	public ModelAndView createBrotherhood() {
		ModelAndView model;
		model = this.createEditModelAndView(this.serviceActor.map(this.serviceActor.createActor(Authority.BROTHERHOOD), Authority.BROTHERHOOD));
		model.addObject("authority", Authority.BROTHERHOOD);
		return model;
	}
	@RequestMapping(value = "/createChapter", method = RequestMethod.GET)
	public ModelAndView createChapter() {
		ModelAndView model;
		model = this.createEditModelAndView(this.serviceActor.map(this.serviceActor.createActor(Authority.CHAPTER), Authority.CHAPTER));
		model.addObject("authority", Authority.CHAPTER);
		return model;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView submit(@ModelAttribute("actor") final ActorForm actor, final BindingResult binding) {
		ModelAndView result = null;

		Administrator admin = null;
		Member member = null;
		Brotherhood brotherhood = null;
		Chapter chapter = null;
		Sponsor sponsor = null;

		try {
			String authority = "";
			boolean urls;
			if (actor.isTerms()) {
				if (actor.getAuthority().equals(Authority.ADMIN)) {
					authority = Authority.ADMIN;
					admin = this.serviceActor.reconstructAdministrator(actor, binding);
				} else if (actor.getAuthority().equals(Authority.BROTHERHOOD)) {
					authority = Authority.BROTHERHOOD;
					brotherhood = this.serviceActor.reconstructBrotherhood(actor, binding);
				} else if (actor.getAuthority().equals(Authority.MEMBER)) {
					authority = Authority.MEMBER;
					member = this.serviceActor.reconstructMember(actor, binding);
				} else if (actor.getAuthority().equals(Authority.CHAPTER)) {
					authority = Authority.CHAPTER;
					chapter = this.serviceActor.reconstructChapter(actor, binding);
				} else if (actor.getAuthority().equals(Authority.SPONSOR)) {
					authority = Authority.SPONSOR;
					sponsor = this.serviceActor.reconstructSponsor(actor, binding);
				}

				if (actor.getAuthority().equals(Authority.BROTHERHOOD))
					if (actor.getPictures().size() > 0)
						urls = Utiles.checkURL(actor.getPictures());
					else
						urls = true;
				else
					urls = true;

				String phone;
				phone = actor.getPhone();
				phone = phone.replace(("+" + Utiles.phonePrefix).trim(), " ").trim();
				if (phone.contains("(") && phone.contains(")")) {
					phone = phone.replace("(", "");
					phone = phone.replace(")", "");
					phone = phone.replace(" ", "");

				}

				boolean checkPhone;
				Long phoneStringToInteger;

				try {
					phoneStringToInteger = Long.valueOf(phone);
					checkPhone = true;
				} catch (final NumberFormatException e) {
					checkPhone = false;
				}

				if (urls && actor.getAccount().getPassword().equals(actor.getPassword2()) && actor.getAccount().getPassword() != "" && actor.getPassword2() != "" && checkPhone) {
					if (actor.getAuthority().equals(Authority.ADMIN))
						this.serviceActor.save(admin, null, null, null, null);
					else if (actor.getAuthority().equals(Authority.BROTHERHOOD))
						this.serviceActor.save(null, brotherhood, null, null, null);
					else if (actor.getAuthority().equals(Authority.MEMBER))
						this.serviceActor.save(null, null, member, null, null);
					else if (actor.getAuthority().equals(Authority.CHAPTER))
						this.serviceActor.save(null, null, null, chapter, null);
					else if (actor.getAuthority().equals(Authority.SPONSOR))
						this.serviceActor.save(null, null, null, null, sponsor);
					result = new ModelAndView("redirect:../security/login.do");
				} else {

					if (actor.getAuthority().equals(Authority.BROTHERHOOD))
						result = this.createEditModelAndView(actor, "actor.passwordOrUrls");
					else
						result = this.createEditModelAndView(actor, "actor.password");

					actor.setTerms(true);

					result.addObject("authority", actor.getAuthority());
				}
			} else {
				result = this.createEditModelAndView(actor, "actor.terms");
				actor.setTerms(false);
				result.addObject("authority", actor.getAuthority());
			}

		} catch (final ValidationException e) {
			actor.setTerms(false);
			result = this.createEditModelAndView(actor);
			result.addObject("authority", actor.getAuthority());
		} catch (final Throwable oops) {
			actor.setTerms(false);
			result = this.createEditModelAndView(actor, "actor.commit.error");
			result.addObject("authority", actor.getAuthority());
		}
		return result;
	}

	@RequestMapping(value = "/personal", method = RequestMethod.GET)
	public ModelAndView editPersonalData() {
		ModelAndView result;
		final Actor a = this.serviceActor.findByUserAccount();
		final ActorForm form = this.serviceActor.map(a, null);
		result = this.createEditModelAndView(form);
		result.addObject("authority", form.getAuthority());
		result.addObject("actorId", a.getAccount().getId());
		result.addObject("own", LoginService.getPrincipal().getId() == a.getAccount().getId());
		result.addObject("notCreate", true);
		result.addObject("polarity", Utiles.homotheticalTransformation(this.messageService.getMessageOutBox(a.getId())));
		final String lang = LocaleContextHolder.getLocale().getLanguage();
		final boolean spam = Utiles.checkSpammer(a);
		result.addObject("spam", spam);

		if (lang.equals("en")) {
			if (spam == true)
				result.addObject("spammer", "Yes");
			else
				result.addObject("spammer", "No");
		} else if (spam == true)
			result.addObject("spammer", "Si");
		else
			result.addObject("spammer", "No");

		return result;
	}

	@RequestMapping(value = "/personalBrotherhood", method = RequestMethod.GET)
	public ModelAndView editPersonalBrotherhood(@RequestParam final int idBrotherhood) {
		ModelAndView result;
		final Brotherhood a = this.serviceActor.findOneBrotherhood(idBrotherhood);
		final ActorForm form = this.serviceActor.map(a, Authority.BROTHERHOOD);
		form.setTerms(true);
		result = this.createEditModelAndView(form);
		result.addObject("check", false);
		result.addObject("notCreate", true);
		result.addObject("polarity", Utiles.homotheticalTransformation(this.messageService.getMessageOutBox(a.getId())));
		result.addObject("actorId", a.getAccount().getId());
		final String lang = LocaleContextHolder.getLocale().getLanguage();
		final boolean spam = Utiles.checkSpammer(a);
		result.addObject("spam", spam);
		if (lang.equals("en")) {
			if (spam == true)
				result.addObject("spammer", "Yes");
			else
				result.addObject("spammer", "No");
		} else if (spam == true)
			result.addObject("spammer", "Si");
		else
			result.addObject("spammer", "No");

		return result;
	}

	@RequestMapping(value = "/export", method = RequestMethod.GET)
	public ModelAndView export(final HttpServletRequest req, final HttpServletResponse res) {
		ModelAndView result;

		Actor actor;
		actor = this.serviceActor.findByUserAccount();

		result = new ModelAndView(new ExportActorDataPDFController(), "actor", actor);

		return result;
	}

	@RequestMapping(value = "/createSponsor", method = RequestMethod.GET)
	public ModelAndView createSponsor() {
		ModelAndView model;
		model = this.createEditModelAndView(this.serviceActor.map(this.serviceActor.createActor(Authority.SPONSOR), Authority.SPONSOR));
		model.addObject("authority", Authority.SPONSOR);
		return model;
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int id) {
		ModelAndView result;
		result = this.custom(new ModelAndView("redirect:../j_spring_security_logout"));
		this.serviceActor.delete(id);
		return result;
	}
	protected <T extends Actor> ModelAndView createEditModelAndView(final T actor) {
		ModelAndView model;
		model = this.createEditModelAndView(actor, null);
		return model;
	}
	protected <T extends Actor> ModelAndView createEditModelAndView(final T actor, final String message) {
		ModelAndView result;
		result = this.custom(new ModelAndView("actor/edit"));

		result.addObject("actor", actor);

		result.addObject("message", message);
		return result;

	}
	protected ModelAndView createEditModelAndView(final ActorForm actor) {
		ModelAndView model;
		model = this.createEditModelAndView(actor, null);
		return model;
	}
	protected ModelAndView createEditModelAndView(final ActorForm actor, final String message) {
		ModelAndView result;
		result = this.custom(new ModelAndView("actor/edit"));
		result.addObject("prefix", Utiles.phonePrefix);
		result.addObject("actor", actor);
		result.addObject("authority", actor.getAuthority());
		result.addObject("check", true);
		result.addObject("message", message);
		return result;

	}

}
