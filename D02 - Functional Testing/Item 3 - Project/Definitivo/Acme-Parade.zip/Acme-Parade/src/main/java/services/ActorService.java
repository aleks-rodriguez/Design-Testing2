
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;

import repositories.AdministratorRepository;
import repositories.BrotherhoodRepository;
import repositories.ChapterRepository;
import repositories.MemberRepository;
import repositories.SponsorRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import security.UserAccountRepository;
import utilities.Utiles;
import domain.Actor;
import domain.Administrator;
import domain.Area;
import domain.Box;
import domain.Brotherhood;
import domain.Chapter;
import domain.Enrolment;
import domain.Finder;
import domain.Float;
import domain.Member;
import domain.Parade;
import domain.Profile;
import domain.Request;
import domain.Sponsor;
import domain.Sponsorship;
import forms.ActorForm;

@Service
@Transactional
public class ActorService {

	@Autowired
	private AdministratorRepository	adminRepository;

	@Autowired
	private MemberRepository		memberRepository;

	@Autowired
	private BrotherhoodRepository	brotherhoodRepository;

	@Autowired
	ChapterRepository				chapterRepository;

	@Autowired
	private BoxService				boxService;

	@Autowired
	private Validator				validator;

	@Autowired
	private FinderService			serviceFinder;

	@Autowired
	private UserAccountRepository	repositoryUser;

	@Autowired
	private SponsorRepository		sponsorRepository;


	public Actor findByUser(final int id) {
		return this.chapterRepository.findById(id);
	}

	public Member findOneMember(final int id) {
		return this.memberRepository.findOne(id);
	}
	public Chapter findOneChapter(final int id) {
		return this.chapterRepository.findOne(id);
	}

	public Collection<Brotherhood> findAllBrotherhood() {
		return this.brotherhoodRepository.findAll();
	}
	public Collection<Parade> findFinalModeParadesByBrotherhoodId(final int id) {
		return this.brotherhoodRepository.getFinalModeParadesByBrotherhoodId(id);
	}
	public Chapter findChapterByUserAccount(final int id) {
		return this.brotherhoodRepository.getChapterByUserAccount(id);
	}
	public Brotherhood findByUserAccount(final int id) {
		return this.brotherhoodRepository.getByUserAccount(id);
	}

	public Member findMemberByUser(final int id) {
		return this.brotherhoodRepository.getMemberByUserAccount(id);
	}

	public Actor findActorByUserAccount(final int id) {
		return this.brotherhoodRepository.getActorByUserAccount(id);
	}

	public Collection<Chapter> findAllChapters() {
		return this.chapterRepository.findAll();
	}

	public Collection<Member> getAllMemberByBrotherhood(final int idBrotherhood) {
		return this.brotherhoodRepository.getAllMemberByBrotherhood(idBrotherhood);
	}

	public Collection<Brotherhood> getAllBrotherhoodActiveByMemberId(final int idMember) {
		return this.brotherhoodRepository.getAllBrotherhoodActiveByMemberId(idMember);
	}

	public Collection<Brotherhood> getAllBrotherhoodDisByMemberId(final int idMember) {
		return this.brotherhoodRepository.getAllBrotherhoodDisByMemberId(idMember);
	}

	public Enrolment getEnrolmentByMemberAndBrother(final int idMember, final int idBrotherhood) {
		return this.brotherhoodRepository.getEnrolmentByMemberAndBrother(idMember, idBrotherhood);
	}

	public Actor findByUserAccount() {
		return this.boxService.getActorByUserAccount(LoginService.getPrincipal().getId());
	}

	public Brotherhood findOneBrotherhood(final int id) {
		return this.brotherhoodRepository.findOne(id);
	}

	public Collection<Brotherhood> getAllBrotherhoodsWithoutYou(final int idBro) {
		return this.brotherhoodRepository.getAllBrotherhoodsWithoutYou(idBro);
	}

	public <T extends Actor> void setBasicProperties(final T actor, final String auth) {
		actor.setProfiles(new ArrayList<Profile>());
		actor.setAdress("");
		actor.setBoxes(new ArrayList<Box>());
		actor.setEmail("");
		actor.setMiddleName("");
		actor.setName("");
		actor.setPhone("");
		actor.setPhoto("");
		actor.setSurname("");
		actor.setSpammer(false);
		actor.setAccount(this.userAccountAdapted("", "", auth));
	}

	public Actor createActor(final String auth) {

		if (auth.equals(Authority.ADMIN)) {
			Assert.isTrue(Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.ADMIN));
			Administrator administrator;
			administrator = new Administrator();
			this.setBasicProperties(administrator, auth);
			return administrator;
		} else if (auth.equals(Authority.BROTHERHOOD)) {
			Brotherhood brotherhood;
			brotherhood = new Brotherhood();

			this.setBasicProperties(brotherhood, auth);

			brotherhood.setTitle("");
			brotherhood.setEstablishment(new Date());
			brotherhood.setPictures(new ArrayList<String>());

			brotherhood.setArea(new Area());
			brotherhood.setEnrolments(new ArrayList<Enrolment>());
			brotherhood.setFloats(new ArrayList<Float>());

			return brotherhood;
		} else if (auth.equals(Authority.MEMBER)) {
			Member member;
			member = new Member();
			this.setBasicProperties(member, auth);

			member.setRequests(new ArrayList<Request>());

			return member;
		} else if (auth.equals(Authority.CHAPTER)) {
			Chapter chapter;
			chapter = new Chapter();
			this.setBasicProperties(chapter, auth);
			chapter.setTitle("");
			return chapter;
		} else if (auth.equals(Authority.SPONSOR)) {
			Sponsor sponsor;
			sponsor = new Sponsor();
			this.setBasicProperties(sponsor, auth);
			sponsor.setSponsorship(new ArrayList<Sponsorship>());
			return sponsor;
		} else
			return null;

	}

	public UserAccount userAccountAdapted(final String username, final String password, final String auth) {

		UserAccount user;
		user = new UserAccount();
		user.setUsername(username);
		user.setPassword(password);
		user.setEnabled(true);

		Authority authority;
		authority = new Authority();
		authority.setAuthority(auth);

		Collection<Authority> authorities;
		authorities = new ArrayList<Authority>();
		authorities.add(authority);
		user.setAuthorities(authorities);

		return user;
	}

	public void setBoxes(final Actor actor) {
		final Collection<Box> boxes = this.boxService.save(Utiles.initBoxes());
		actor.setBoxes(boxes);
	}
	public Actor save(final Administrator admin, final Brotherhood brotherhood, final Member member, final Chapter chapter, final Sponsor sponsor) {
		Actor saved = null;

		if (admin != null) {
			if (admin.getId() != 0)
				Assert.isTrue(LoginService.getPrincipal().getId() == admin.getAccount().getId());
			Assert.isTrue(Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.ADMIN));

			if (admin.getId() == 0) {
				UserAccount user;
				user = this.repositoryUser.save(admin.getAccount());
				admin.setAccount(user);
			}

			saved = this.adminRepository.save(admin);
		} else if (brotherhood != null) {
			if (brotherhood.getId() != 0)
				Assert.isTrue(LoginService.getPrincipal().getId() == brotherhood.getAccount().getId());

			if (brotherhood.getId() == 0) {
				UserAccount user;
				user = this.repositoryUser.save(brotherhood.getAccount());
				brotherhood.setAccount(user);
			}

			saved = this.brotherhoodRepository.save(brotherhood);
		} else if (member != null) {
			if (member.getId() != 0)
				Assert.isTrue(LoginService.getPrincipal().getId() == member.getAccount().getId());

			if (member.getId() == 0) {
				UserAccount user;
				user = this.repositoryUser.save(member.getAccount());
				member.setAccount(user);
			}

			saved = this.memberRepository.save(member);
		} else if (chapter != null) {
			if (chapter.getId() != 0)
				Assert.isTrue(LoginService.getPrincipal().getId() == chapter.getAccount().getId());
			if (chapter.getId() == 0) {
				UserAccount user;
				user = this.repositoryUser.save(chapter.getAccount());
				chapter.setAccount(user);
			}

			saved = this.chapterRepository.save(chapter);
		} else if (sponsor != null) {
			if (sponsor.getId() != 0)
				Assert.isTrue(LoginService.getPrincipal().getId() == sponsor.getAccount().getId());

			if (sponsor.getId() == 0) {
				UserAccount user;
				user = this.repositoryUser.save(sponsor.getAccount());
				sponsor.setAccount(user);
			}

			saved = this.sponsorRepository.save(sponsor);
		}
		return saved;
	}

	public Administrator reconstructAdministrator(final ActorForm actor, final BindingResult binding) {
		Administrator result = null;

		if (actor.getId() == 0) {
			result = (Administrator) this.createActor(Authority.ADMIN);
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
			if (!binding.hasErrors())
				this.setBoxes(result);
		} else {
			result = this.adminRepository.findOne(actor.getId());
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
		}

		if (binding.hasErrors())
			throw new ValidationException();

		return result;
	}

	public Brotherhood reconstructBrotherhood(final ActorForm actor, final BindingResult binding) {

		Brotherhood result = null;

		if (actor.getId() == 0) {
			result = (Brotherhood) this.createActor(Authority.BROTHERHOOD);
			this.setToActor(result, actor);
			result.setPictures(actor.getPictures());
			result.setTitle(actor.getTitle());
			this.validator.validate(result, binding);
			if (!binding.hasErrors()) {
				this.setBoxes(result);
				result.setArea(null);
			}
		} else {
			result = this.brotherhoodRepository.findOne(actor.getId());
			this.setToActor(result, actor);
			result.setPictures(actor.getPictures());
			result.setTitle(actor.getTitle());
			this.validator.validate(result, binding);
		}

		if (binding.hasErrors())
			throw new ValidationException();

		return result;
	}

	public Member reconstructMember(final ActorForm actor, final BindingResult binding) {
		Member result = null;

		if (actor.getId() == 0) {
			result = (Member) this.createActor(Authority.MEMBER);
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
			if (!binding.hasErrors()) {
				this.setBoxes(result);
				Finder finder;
				finder = this.serviceFinder.save(this.serviceFinder.createFinder());
				result.setFinder(finder);

			}

		} else {
			result = this.memberRepository.findOne(actor.getId());
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
		}
		if (binding.hasErrors())
			throw new ValidationException();

		return result;
	}

	public Chapter reconstructChapter(final ActorForm actor, final BindingResult binding) {
		Chapter result;

		if (actor.getId() == 0) {
			result = (Chapter) this.createActor(Authority.CHAPTER);
			this.setToActor(result, actor);
			result.setTitle(actor.getTitle());
			this.validator.validate(result, binding);
			if (!binding.hasErrors())
				this.setBoxes(result);
		} else {
			result = this.chapterRepository.findOne(actor.getId());
			this.setToActor(result, actor);
			result.setTitle(actor.getTitle());
			this.validator.validate(result, binding);
		}
		if (binding.hasErrors())
			throw new ValidationException();
		return result;
	}

	public <T extends Actor> void setToActor(final T result, final ActorForm actor) {

		result.setName(actor.getName());
		result.setAdress(actor.getAdress());
		result.setPhone(actor.getPhone());
		result.setPhoto(actor.getPhoto());
		result.setSurname(actor.getSurname());
		result.setEmail(actor.getEmail());
		result.setMiddleName(actor.getMiddleName());

		if (result.getAccount().getId() == 0) {
			if (actor.getAccount().getPassword().equals(actor.getPassword2()))
				result.setAccount(this.userAccountAdapted(actor.getAccount().getUsername(), Utiles.hashPassword(actor.getAccount().getPassword()), actor.getAuthority()));
		} else {
			UserAccount ua;
			ua = this.repositoryUser.findOne(result.getAccount().getId());
			if (actor.getAccount().getPassword().equals(actor.getPassword2())) {
				if (!ua.getUsername().equals(actor.getAccount().getUsername()))
					ua.setUsername(actor.getAccount().getUsername());
				ua.setPassword(Utiles.hashPassword(actor.getAccount().getPassword()));
			}
		}

	}
	public ActorForm map(final Actor a, String auth) {

		ActorForm form;
		form = new ActorForm();

		if (auth == null) {
			auth = LoginService.getPrincipal().getAuthorities().toString();
			auth = auth.substring(1, auth.toString().length() - 1);
		}
		if (a.getId() == 0) {

			form.setAdress("");
			form.setAuthority(auth);
			form.setEmail("");
			form.setMiddleName("");

			form.setAccount(this.userAccountAdapted("", "", auth));

			form.setPassword2("");
			form.setPhone("");
			form.setSurname("");
			form.setPhoto("");
			form.setName("");
			if (auth.equals(Authority.BROTHERHOOD)) {
				form.setPictures(new ArrayList<String>());
				form.setTitle("");
			}
			if (auth.equals(Authority.CHAPTER))
				form.setTitle("");

		} else {
			form.setId(a.getId());
			form.setAdress(a.getAdress());
			form.setAuthority(auth);
			form.setEmail(a.getEmail());
			form.setMiddleName(a.getMiddleName());
			form.setSurname(a.getSurname());
			form.setPassword2("");
			form.setPhone(a.getPhone());
			form.setAccount(this.userAccountAdapted(a.getAccount().getUsername(), "", auth));
			form.setPhoto(a.getPhoto());
			form.setName(a.getName());
			if (auth.equals(Authority.BROTHERHOOD)) {
				final Brotherhood b = (Brotherhood) a;
				form.setPictures(b.getPictures());
				form.setTitle(b.getTitle());
			}
			if (auth.equals(Authority.CHAPTER)) {
				final Chapter c = (Chapter) a;
				form.setTitle(c.getTitle());
			}
			form.setTerms(true);
		}

		return form;
	}
	//sponsor
	public Collection<Sponsorship> getSponsorshipsBySponsor(final Sponsor s) {

		Collection<Sponsorship> result;
		Assert.notNull(s);
		result = this.sponsorRepository.getSponsorshipsBySponsor(s.getId());
		Assert.isTrue(result.size() >= 0);
		return result;
	}

	public Sponsor reconstructSponsor(final ActorForm actor, final BindingResult binding) {

		Sponsor result = null;

		if (actor.getId() == 0) {
			result = (Sponsor) this.createActor(Authority.SPONSOR);
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
			if (!binding.hasErrors())
				this.setBoxes(result);
		} else {
			result = this.sponsorRepository.findOne(actor.getId());
			this.setToActor(result, actor);
			this.validator.validate(result, binding);
		}

		if (binding.hasErrors())
			throw new ValidationException();

		return result;
	}

	public Sponsor findById(final int id) {
		return this.sponsorRepository.findOne(id);
	}

	public Sponsor findSponsorByUserAccount(final int userAccount) {
		Assert.notNull(userAccount);
		return this.sponsorRepository.findByUserAccount(userAccount);
	}

	public Collection<Sponsor> findAll() {
		return this.sponsorRepository.findAll();
	}

	public void delete(final int actorId) {
		Assert.notNull(LoginService.getPrincipal().getUsername());
		Administrator admin;
		Brotherhood brotherhood;
		Member member;
		Chapter chapter;
		Sponsor sponsor;
		if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.ADMIN)) {
			admin = this.adminRepository.getAdministratorByUserAccountId(actorId);
			//			Assert.isTrue(this.adminRepository.getAdministratorByUserAccountId(LoginService.getPrincipal().getId()).getId() == actorId, "Delete not allowed");
			Assert.isTrue(LoginService.getPrincipal().getId() == actorId, "Delete not allowed");

			admin.getAccount().setEnabled(false);
			admin.setName("anonymous");
			admin.setMiddleName("anonymous");
			admin.setPhone("anonymous");
			admin.setSurname("anonymous");
			admin.setPhone("anonymous");
			admin.setEmail("anonymous@email.anon");
			this.adminRepository.save(admin);
		} else if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.BROTHERHOOD)) {
			brotherhood = this.brotherhoodRepository.getByUserAccount(actorId);
			//			Assert.isTrue(this.brotherhoodRepository.getByUserAccount(LoginService.getPrincipal().getId()).getId() == actorId, "Delete not allowed");
			Assert.isTrue(LoginService.getPrincipal().getId() == actorId, "Delete not allowed");
			brotherhood.getAccount().setEnabled(false);
			brotherhood.setName("anonymous");
			brotherhood.setMiddleName("anonymous");
			brotherhood.setPhone("anonymous");
			brotherhood.setSurname("anonymous");
			brotherhood.setPhone("anonymous");
			brotherhood.setEmail("anonymous@email.anon");
			this.brotherhoodRepository.save(brotherhood);
		} else if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.CHAPTER)) {
			chapter = this.chapterRepository.findActorByUserAccount(actorId);
			Assert.isTrue(LoginService.getPrincipal().getId() == actorId, "Delete not allowed");
			chapter.getAccount().setEnabled(false);
			chapter.setName("anonymous");
			chapter.setMiddleName("anonymous");
			chapter.setPhone("anonymous");
			chapter.setSurname("anonymous");
			chapter.setPhone("anonymous");
			chapter.setEmail("anonymous@email.anon");
			this.chapterRepository.save(chapter);
		} else if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.MEMBER)) {
			member = this.memberRepository.findByUserAccount(actorId);
			//		Assert.isTrue(this.memberRepository.findActorByUserAccount(LoginService.getPrincipal().getId()).getId() == actorId, "Delete not allowed");
			Assert.isTrue(LoginService.getPrincipal().getId() == actorId, "Delete not allowed");
			member.getAccount().setEnabled(false);
			member.setName("anonymous");
			member.setMiddleName("anonymous");
			member.setPhone("anonymous");
			member.setSurname("anonymous");
			member.setPhone("anonymous");
			member.setEmail("anonymous@email.anon");
			this.memberRepository.save(member);
		} else if (Utiles.findAuthority(LoginService.getPrincipal().getAuthorities(), Authority.SPONSOR)) {
			sponsor = this.sponsorRepository.findByUserAccount(actorId);
			//			Assert.isTrue(this.sponsorRepository.findByUserAccount(LoginService.getPrincipal().getId()).getId() == actorId, "Delete not allowed");
			Assert.isTrue(LoginService.getPrincipal().getId() == actorId, "Delete not allowed");

			sponsor.getAccount().setEnabled(false);
			sponsor.setName("anonymous");
			sponsor.setMiddleName("anonymous");
			sponsor.setPhone("anonymous");
			sponsor.setSurname("anonymous");
			sponsor.setPhone("anonymous");
			sponsor.setEmail("anonymous@email.anon");
			this.sponsorRepository.save(sponsor);
		}
	}
	public void flushAdministrator() {
		this.adminRepository.flush();
	}
	public void flushMember() {
		this.memberRepository.flush();
	}
	public void flushBrotherhood() {
		this.brotherhoodRepository.flush();
	}
	public void flushRepository() {
		this.repositoryUser.flush();
	}
	public void flushChapter() {
		this.chapterRepository.flush();
	}
	public void flushSponsor() {
		this.sponsorRepository.flush();
	}
}
