The following information is given to Desing and Testing 2 Teachers 
with the purpose of they access to our project. 
Other uses are not allowed.

If you want to get in our project 
you will have to log into https://github.com/login
and write the following parameters:

# Repository�s Username
* dpprofesores
# Repository�s Password
* @$DP1819_F133/G2

After you log in, you have to see 
on the left of the User Webpage
a box which contains all the repositories. 
For us, Design and Testing 2 created by Angel Delgado.
You click on, and will you see 
all the information related to the deliverable.

Things to take into account before you see our deliverable:

1. Make use of the provide Script SQL (create-acme-madruga.sql) to initialize Database.