ADMIN 1

User: admin1
Pass: e00cf25ad42683b3df678c61f42c6bda

ADMIN 2

User: admin2
Pass: c84258e9c39059a89ab77d846ddab909

BROTHERHOOD 1

User: brotherhood1
Pass: 479e3180a45b21ea8e88beb0c45aa8ed

BROTHERHOOD 2

User: brotherhood2
Pass: 88f1b810c40cd63107fb758fef4d77db

MEMBER 1

User: member1
Pass: c7764cfed23c5ca3bb393308a0da2306

MEMBER 2

User: member2
Pass: 88ed421f060aadcacbd63f28d889797f

* La contrase�a es el propio usuario.