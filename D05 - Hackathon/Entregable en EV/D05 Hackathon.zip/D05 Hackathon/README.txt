The following information is given to Desing and Testing 2 Teachers 
with the purpose of they access to our project. 
Other uses are not allowed.

If you want to get in our project 
you will have to log into https://github.com/login
and write the following parameters:

# Repository�s Username
* dpprofesores
# Repository�s Password
* @$DP1819_F133/G2

After you log in, you have to see 
on the left of the User Webpage
a box which contains all the repositories. 
For us, Design and Testing 2 created by Angel Delgado.

The previous repository has been used as files cloud system.

The repository which contains the programming code and the management hold 
along this deliverable can be found at:

htttps://www.github.com/angel96/DEL5

If any problem is detected when loggin in any, 
please contact urgently if it is convenient with Angel Delgado.

angdellun@alum.us.es

You click on, and you will see 
all the information related to the deliverable.

Things to take into account before you see our deliverable:

1. Make use of the provide Script SQL (create-del5.sql) to initialize Database.

2. Ticker generation has completely been changed respect to previous deliverables.
   Now, it is given the possibility of being used by any entity without any extra implementation.

2.1 String parameter from ticker entity is generated using a library called "Generex".
    It receives as parameter a string which is the pattern of the strings we want to generate.

3. This project has a cache function specially defined for CustomisationSystem and Proclaims.
   If any modification is no appreciated at the moment, do not worry.