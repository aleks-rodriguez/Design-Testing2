The following information is given to Desing and Testing 2 Teachers 
with the purpose of they access to our project. 
Other uses are not allowed.

If you want to get in our project 
you will have to log into https://github.com/login
and write the following parameters:

# Repository�s Username
* dpprofesores
# Repository�s Password
* @$DP1819_F133/G2

After you log in, you have to see 
on the left of the User Webpage
a box which contains all the repositories. 
For us, Design and Testing 2 created by Angel Delgado.
You click on, and will you see 
all the information related to the deliverable.

Things to take into account before you see our deliverable:

1. Make use of the provide Script SQL (create-acme-hackerrank.sql) to initialize Database.

2. Hibernate Search doesn�t work properly in production due to the amount of threads used by Spring, 
   Tomcat and Lucene at the same time. This does not happen in Developer or Pre Production.
   Free clever cloud plan works with 5 max threads. When Tomcat and MySQL are both working, it is created more than 4 threads.
   According to this reason, It�s necessary to use a bigger plan which lets our project to use the technology mentioned.